from django.apps import AppConfig


class ResumedetailsConfig(AppConfig):
    name = 'resumeDetails'
